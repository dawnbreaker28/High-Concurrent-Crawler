SOURCE_FILE = 'test.tsv'
SEARCH_DEPTH = 3
RESULT_DIR = 'results/authority_content/'
