import threading
from utils.kafka_instance import producer
import json

def send_message(topic, message):
    """使用全局KafkaProducer实例发送消息"""
    producer.send(topic, message)
    producer.flush()  # 确保消息被立即发送
    print(f"Message sent to {topic}")


def send_message_to_unknown_type(topic, content):
    # 假设消费者期望接收的消息是JSON格式的
    if isinstance(content, bytes):
        # 如果 message 是 bytes 类型，先解码
        message = content.decode('utf-8')
    else:
        message = {
        'html_content': content
        }
    message_json = json.dumps(message)  # 序列化为JSON字符串
    print(message_json)
    producer.send(topic, message_json.encode('utf-8'))
    producer.flush()


def start_producer_thread(topic, message):
    """创建并启动一个线程来发送消息"""
    producer_thread = threading.Thread(
        target=send_message,
        args=(topic, message)
    )
    producer_thread.start()
    return producer_thread